package com.example.myapplication_app;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.RequiresApi;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends Activity {    //die Klasse MainActivity ist für das bedingte erscheinen des Startbildschirms mit dem Logo zuständig

    public final int wartezeit = 4000;  //Zeit, die der Startbilschirm zu sehen sein soll

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {    //Hier wirdd der Bildschirm aufgerufen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Startbildschirm Layout wird aufgerufen

        new Handler().postDelayed(new Runnable() {  //bedingtes Aufrufen des Startbildschirms
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, Inhalt.class); //erst soll die MainActivity aufgerufen werden(der Startbildschirm)
                startActivity(intent);                                                      //danach soll die Klasse Inhalt aufgerufen werden (Produktivumgebung der App)
                finish(); //zum Schluss muss die MainActivity sich alleine beenden
            }
        }, wartezeit);  //solange ist der Startbildschirm zu sehen
    }
}


