
package com.example.myapplication_app;

        import android.app.Activity;
        import android.os.Build;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.EditText;
        import android.widget.ListView;

        import androidx.annotation.RequiresApi;

        import org.apache.commons.io.FileUtils;

        import java.io.File;
        import java.io.IOException;
        import java.util.ArrayList;

public class Inhalt extends Activity { //In der Klasse Inhalt wird die Umgebung der App an sich programmiert
    private ArrayList<String> aufgabe;
    private ArrayAdapter<String> aufgabenAdapter;
    private ListView listenAnsicht;

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {    //sorgt für das erscheinen aller Komponenten,...
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu); //Produktivumgebung wird aufgerufen


        listenAnsicht = (ListView) findViewById(R.id.lvItems);
        aufgabe = new ArrayList<String>();
        readItems();
        aufgabenAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, aufgabe);
        listenAnsicht.setAdapter(aufgabenAdapter);

        setupListViewListener();
    }

    private void setupListViewListener(){
        listenAnsicht.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { //bei längerem gedrückt halten sollen ToDos gelöscht werden
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //Aufgabe entfernen, an der angeklickten Position
                aufgabe.remove(position);
                //Adapter wird benachrichtigt dass sich die Daten geändert haben
                aufgabenAdapter.notifyDataSetChanged();
                writeItems();
                return true;
            }
        });

    }

    public void onAddItem(View v){      //hier wird sich um das Hinzufügen neuer ToDo's gekümmert
        EditText addAufgabe = (EditText) findViewById(R.id.addAufgabe);     //Aufgabe, die Eingegeben wurde
        String aufgabenText = addAufgabe.getText().toString();      //String-Wert der Aufgabe einlesen
        aufgabenAdapter.add(aufgabenText);      //String der Liste aufgabenAdapter hinzufügen
        addAufgabe.setText("");             //den Inhalt, der Zeile zum eintragen von neuen Aufgaben, wieder auf einen leeren String setzen
        writeItems();
    }


    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    //jetzt wird sich um das speichern der Einträge fürs nächste öffnen gekümmert


    private void readItems() {      //die bestehenden Aufgaben werden eingelesen
        File filesDir = getFilesDir();
        File todoFile = new File(filesDir, "todo.txt");
        try {
            aufgabe = new ArrayList<String>(FileUtils.readLines(todoFile));
        } catch (IOException e) {
            aufgabe = new ArrayList<String>();
        }
    }

    private void writeItems() {         //die oben eingelesenen Aufgaben werden ausgegeben wenn die App wieder geöffnet wird
        File filesDir = getFilesDir();
        File todoFile = new File(filesDir, "todo.txt");
        try {
            FileUtils.writeLines(todoFile, aufgabe);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


